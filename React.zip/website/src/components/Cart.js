import React from 'react';
import '../Styles/Cart.css';
import {ProductConsumer} from '../context';
import Product from './Product';
class Cart extends React.Component{
    render(){
        return(
            <React.Fragment>
               <h2 className="cart text-center">Cart</h2>
               <div className="container">
                   
                   <div className="row">
                        <ProductConsumer>
                          {(value)=>{
                            return value.products.map(product=>{
                              return <Product key={product.id} product={product}/>;
                            })

                          }}
                        </ProductConsumer>
                   </div>
                   
              </div>
           
      </React.Fragment>
            
        );
    }
}
export default Cart;