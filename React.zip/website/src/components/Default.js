import React from 'react';
class Default extends React.Component{
    render(){
        return(
            <div>
                <h3>Page not found</h3>
            </div>
        );
    }
}
export default Default;