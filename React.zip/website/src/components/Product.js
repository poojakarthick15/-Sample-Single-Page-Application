import React from 'react';
import {Link} from 'react-router-dom';

import '../Styles/Product.css';



class Product extends React.Component{
    render(){
        const {title,img,price}=this.props.product;
        return(
            <div className="col-9 mx-auto col-md-6 col-lg-3 my-3">
                <div className="card">
                    <div className="img-container p-5" onClick={console.log('you clicked me')}>
                        <Link to="/details">
                            <img src={img} alt="product" className="card-img-top"></img>
                        </Link>
                        <button className="cart-btn">
                    
                        
                    <i className="fa fa-cart-plus"></i>
                    
                    </button>

                    </div>
                    <div className="card-footer d-flex justify-content-between">
                        <p className="align-self-center mb-0">
                            {title}
                        </p>
                        <h5 className="text-info font-italic mb-0">
                            <span className="mr-1"> &#8377;</span>
                            {price}
                        </h5>
                    </div>
                </div>
            </div>
        );
    }
}
export default Product;

