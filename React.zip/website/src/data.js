export const storeProducts = [
    {
      id: 1,
      title:"Inspiron 14 5490 Laptop",
      img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRt-LV7z-qprh9T14cisUVA0ho9Ci_N-2FtonvhUVH0Mp4XxrqHrKB5N1WT_s9L8upQYhb3KQM&usqp=CAc",
      price:63000,
      
    },
    {
      id: 2,
      title: "New Inspiron 15 7501 Laptop",
      img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRcJy2qbeiHxYISymLZyVGg0lZT58XYHDHvGqm_xyFIZMUV8bJPs96YNgIT-X7mwLrzf7RjZ6Gd&usqp=CAc",
      price: 54000,
      
    },
    {
      id: 3,
      title: "Acer Nitro 5 Intel Core i5",
      img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRPDdS77gni2o3bZWajM8Cjjfikhx2ZwXKaVjD1MTldTAh-gOPBKYsHEqL2QMX9b_SlUNa39xw&usqp=CAc",
      price: 43000
      
    },
    {
      id: 4,
      title: "Lenovo Ideapad S145 AMD Ryzen 5",
      img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSObrabcA39MASqJia9d-o0mSwiYdP1qZBEJTkmUjjMceReFRksyeue1-hQfD5k2Nk0BcDwjk4&usqp=CAc",
      price: 65000
      
    },
    {
      id: 5,
      title: "DELL Inspiron 5491 2in1 Touchscreen 14-inch Laptop",
      img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSObrabcA39MASqJia9d-o0mSwiYdP1qZBEJTkmUjjMceReFRksyeue1-hQfD5k2Nk0BcDwjk4&usqp=CAc",
      price: 73000
      
    },
    {
      id: 6,
      title: "ASUS VivoBook 14",
      img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTQol4NLbUEH6QYd63eVmEKyi5nEqB1Te3gLKqVq2nm_8kWzkh-3IPvnnv0jJgbCxI7rMJYzKw&usqp=CAc",
      price: 76000
      
      
    },
    {
      id: 7,
      title: "Mi Notebook 14 Horizon Gray",
      img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSObrabcA39MASqJia9d-o0mSwiYdP1qZBEJTkmUjjMceReFRksyeue1-hQfD5k2Nk0BcDwjk4&usqp=CAc",
      price: 38000,
      
    },
    {
      id: 8,
      title: "AVITA LIBER V14 NS14A8INF562",
      img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTQol4NLbUEH6QYd63eVmEKyi5nEqB1Te3gLKqVq2nm_8kWzkh-3IPvnnv0jJgbCxI7rMJYzKw&usqp=CAc",
      price: 32000
      
    }
  ];
  
  